'use strict';

const express = require('express');
const app = express();

app.use(express.urlencoded({extended:false}))
app.use(express.json());


app.use(function(req, res, next) {
  res.setHeader("Content-Type", "application/json");
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST');
  res.header('Allow', 'GET, POST');
  next();
});

var StoreCandidates=[
  {
    "id": "ae588a6b-4540-5714-bfe2-a5c2a65f547aD",
    "name": "Jimmy Coder1",
    "habilidades": [ "javascript", "es6", "nodejs", "express","ejs" ]
  }
,
  {
    "id": "ae588a6b-4540-5714-bfe2-a5c2a65f547aV",
    "name": "Jimmy Coder2",
    "habilidades": [ "react", "nodejs", "html" ,"css"]
  }
,
  {
    "id": "ae588a6b-4540-5714-bfe2-a5c2a65f547aK",
    "name": "Jimmy Coder3",
    "habilidades": [ "css", "vue", "html" ,"mongo"]
  }
  ,{
    "id": "ae588a6b-4540-5714-bfe2-a5c2a65f547aI",
    "name": "Jimmy Coder4",
    "habilidades": [ "css","nodejs","native","redux","word"]
  }
];
var FilterCandidates= new Set();
var MejorCandidato;

// Your code starts here. Placeholders for .get and .post are provided for
//  your convenience.

app.post('/candidates', function (req, res) {
  console.log("Valide Form ",validarResq)
var data=req.body;
StoreCandidates.push(data);
res.json({"code":200,msg:"Candidate register ."})
});

app.get('/candidates/search', function (req, res) {
  MejorCandidato="";
 const  {skills} = req.query;
 if(Object.values(StoreCandidates).length > 0){
  for (const key in StoreCandidates) {
    var nHabilidades =0;
     const {habilidades} = StoreCandidates[key];
     ///CANDIDATOS QUE CUMPLE CON LAS HABILIDADES 
     var A_skills = skills.split(",");
     for (let index = 0; index < A_skills.length; index++) {
        if(habilidades.some(value => value == A_skills[index])){
          nHabilidades+=1;
          FilterCandidates.add({...StoreCandidates[key],nHabilidades,nskills:habilidades.length}) 
        }
            }       
    }

    if(FilterCandidates.size > 0){
      console.log("CANDIDATOS ",FilterCandidates)
     //Posibles candidatos
      var setArray=Array.from(FilterCandidates);
      var select =0
      var nSkillReg=0
     for (let ind = 0; ind < setArray.length; ind++) {
      const {nHabilidades,nskills,name}= setArray[ind];
      if(select==0){
        select=nHabilidades;
        MejorCandidato=setArray[ind];
      }
    
        
      if (parseInt(nHabilidades) > parseInt(select)) {
     
       if ( parseInt(nskills) > parseInt(nSkillReg) ) {
        nSkillReg=nskills;
        MejorCandidato=setArray[ind];
       }

       
      
      }
    
      select=nHabilidades;
     
     }
    }

    if (MejorCandidato!="") {
      const{id,name,habilidades}=MejorCandidato;
      res.json({code:200,msg:{id,name,habilidades}});
      return;
    }else{
      res.json({code:404,msg:"No existen cadidatos con las habilidades requeridas"})
      return
    }

  
    if(Array.from(FilterCandidates) == 0 && Object.values(StoreCandidates).length>0){
  
      res.json({code:404,msg:"No existen cadidatos con las habilidades requeridas"})
      return
    }

    // console.log()
    // console.log(Array.from(FilterCandidates))
}

if(Object.values(StoreCandidates).length == 0){
res.json({code:404,msg:"No existen cadidatos registrados en la colección"})
}
});


function validarResq(data){
  var flag= true;
  const {id:id_val,name:name_val,habilidades:hab_val} = data;
  console.log(id_val," ** ",name_val," ** ",hab_val)
  if(Object.values(StoreCandidates).length>0){
    for (const key in StoreCandidates) {
      console.log(StoreCandidates[key])
      }
  }
return flag;
}

app.listen(process.env.HTTP_PORT || 3000);
